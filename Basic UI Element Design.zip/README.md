
  # Basic UI Element Design

  This is a code bundle for Basic UI Element Design. The original project is available at https://www.figma.com/design/cPGxHSL6uniAfdK2X9drJk/Basic-UI-Element-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  