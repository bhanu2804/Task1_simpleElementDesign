import { useState } from 'react';
import { Card } from './components/ui/card';
import { Label } from './components/ui/label';
import { Slider } from './components/ui/slider';
import { Badge } from './components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { 
  Sun, 
  Cloud, 
  CloudRain, 
  CloudSnow, 
  Wind, 
  CloudLightning,
  Eye,
  Palette,
  Ruler
} from 'lucide-react';

type IconStyle = 'filled' | 'outline' | 'minimal';
type WeatherType = 'sun' | 'cloud' | 'rain' | 'snow' | 'wind' | 'storm';

export default function App() {
  const [selectedIcon, setSelectedIcon] = useState<WeatherType>('sun');
  const [iconStyle, setIconStyle] = useState<IconStyle>('filled');
  const [iconSize, setIconSize] = useState(64);
  const [strokeWidth, setStrokeWidth] = useState(2);
  const [iconColor, setIconColor] = useState('#3b82f6');

  const weatherIcons = [
    { type: 'sun' as WeatherType, label: 'Sunny', icon: Sun, color: '#f59e0b' },
    { type: 'cloud' as WeatherType, label: 'Cloudy', icon: Cloud, color: '#94a3b8' },
    { type: 'rain' as WeatherType, label: 'Rainy', icon: CloudRain, color: '#3b82f6' },
    { type: 'snow' as WeatherType, label: 'Snowy', icon: CloudSnow, color: '#38bdf8' },
    { type: 'wind' as WeatherType, label: 'Windy', icon: Wind, color: '#6366f1' },
    { type: 'storm' as WeatherType, label: 'Stormy', icon: CloudLightning, color: '#a855f7' },
  ];

  const colorPresets = [
    { name: 'Blue', value: '#3b82f6' },
    { name: 'Orange', value: '#f97316' },
    { name: 'Yellow', value: '#f59e0b' },
    { name: 'Purple', value: '#a855f7' },
    { name: 'Gray', value: '#64748b' },
    { name: 'Teal', value: '#14b8a6' },
  ];

  const selectedWeather = weatherIcons.find(w => w.type === selectedIcon)!;
  const IconComponent = selectedWeather.icon;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-full mb-4 text-sm">
            <Palette className="w-4 h-4" />
            Task 4: Icon Design
          </div>
          <h1 className="mb-4">Weather Icon Designer</h1>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Learn to design recognizable and intuitive icons for a weather app.
            Experiment with different styles, sizes, and colors to create effective visual communication.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Controls Panel */}
          <div className="lg:col-span-1 space-y-6">
            {/* Weather Type Selection */}
            <Card className="p-6 bg-white shadow-lg">
              <h3 className="mb-4">1. Choose Weather Icon</h3>
              <div className="grid grid-cols-2 gap-3">
                {weatherIcons.map((weather) => {
                  const Icon = weather.icon;
                  return (
                    <button
                      key={weather.type}
                      onClick={() => {
                        setSelectedIcon(weather.type);
                        setIconColor(weather.color);
                      }}
                      className={`p-4 rounded-lg border-2 transition-all ${
                        selectedIcon === weather.type
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <Icon 
                        className="w-8 h-8 mx-auto mb-2" 
                        style={{ color: weather.color }}
                      />
                      <div className="text-sm">{weather.label}</div>
                    </button>
                  );
                })}
              </div>
            </Card>

            {/* Style Selection */}
            <Card className="p-6 bg-white shadow-lg">
              <h3 className="mb-4">2. Icon Style</h3>
              <div className="space-y-3">
                <button
                  onClick={() => setIconStyle('filled')}
                  className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                    iconStyle === 'filled'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div>Filled</div>
                      <div className="text-sm text-slate-500">Solid, bold appearance</div>
                    </div>
                    <Sun className="w-6 h-6" fill={iconStyle === 'filled' ? 'currentColor' : 'none'} />
                  </div>
                </button>
                <button
                  onClick={() => setIconStyle('outline')}
                  className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                    iconStyle === 'outline'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div>Outline</div>
                      <div className="text-sm text-slate-500">Clean, modern lines</div>
                    </div>
                    <Sun className="w-6 h-6" />
                  </div>
                </button>
                <button
                  onClick={() => setIconStyle('minimal')}
                  className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                    iconStyle === 'minimal'
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <div>Minimal</div>
                      <div className="text-sm text-slate-500">Simple, lightweight</div>
                    </div>
                    <Sun className="w-6 h-6" strokeWidth={1} />
                  </div>
                </button>
              </div>
            </Card>

            {/* Size Controls */}
            <Card className="p-6 bg-white shadow-lg">
              <h3 className="mb-4 flex items-center gap-2">
                <Ruler className="w-5 h-5" />
                3. Customize
              </h3>
              <div className="space-y-6">
                <div>
                  <Label className="mb-3 block">Size: {iconSize}px</Label>
                  <Slider
                    value={[iconSize]}
                    onValueChange={(value) => setIconSize(value[0])}
                    min={32}
                    max={128}
                    step={8}
                  />
                </div>
                <div>
                  <Label className="mb-3 block">Stroke Width: {strokeWidth}px</Label>
                  <Slider
                    value={[strokeWidth]}
                    onValueChange={(value) => setStrokeWidth(value[0])}
                    min={1}
                    max={4}
                    step={0.5}
                  />
                </div>
                <div>
                  <Label className="mb-3 block">Color</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {colorPresets.map((color) => (
                      <button
                        key={color.value}
                        onClick={() => setIconColor(color.value)}
                        className={`p-2 rounded-lg border-2 transition-all ${
                          iconColor === color.value
                            ? 'border-slate-800 scale-105'
                            : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div
                          className="w-full h-8 rounded"
                          style={{ backgroundColor: color.value }}
                        />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Preview & Education Panel */}
          <div className="lg:col-span-2 space-y-6">
            {/* Main Preview */}
            <Card className="p-8 bg-white shadow-lg">
              <div className="flex items-center justify-between mb-6">
                <h2 className="flex items-center gap-2">
                  <Eye className="w-5 h-5" />
                  Preview
                </h2>
                <Badge variant="outline">{selectedWeather.label}</Badge>
              </div>
              
              <div className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg p-16 min-h-[400px] flex items-center justify-center">
                <div className="text-center">
                  <IconComponent
                    style={{ 
                      color: iconColor,
                      width: iconSize,
                      height: iconSize,
                      strokeWidth: iconStyle === 'minimal' ? 1 : strokeWidth,
                      fill: iconStyle === 'filled' ? iconColor : 'none'
                    }}
                    className="mx-auto mb-4"
                  />
                  <div className="text-slate-600 text-sm">{iconSize}px × {iconSize}px</div>
                </div>
              </div>

              {/* Size Comparison */}
              <div className="mt-6 p-4 bg-slate-50 rounded-lg">
                <div className="text-sm mb-3">Size Comparison</div>
                <div className="flex items-center gap-6 justify-center">
                  {[24, 32, 48, 64, 80].map((size) => (
                    <div key={size} className="text-center">
                      <IconComponent
                        style={{ 
                          color: iconColor,
                          width: size,
                          height: size,
                          strokeWidth: iconStyle === 'minimal' ? 1 : strokeWidth,
                          fill: iconStyle === 'filled' ? iconColor : 'none'
                        }}
                        className="mx-auto mb-1"
                      />
                      <div className="text-xs text-slate-500">{size}px</div>
                    </div>
                  ))}
                </div>
              </div>
            </Card>

            {/* Educational Content */}
            <Card className="p-8 bg-white shadow-lg">
              <Tabs defaultValue="principles" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="principles">Principles</TabsTrigger>
                  <TabsTrigger value="guidelines">Guidelines</TabsTrigger>
                  <TabsTrigger value="examples">Context</TabsTrigger>
                </TabsList>
                
                <TabsContent value="principles" className="space-y-4 mt-6">
                  <div className="space-y-4">
                    <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="mb-1">🎯 Recognizability</div>
                      <div className="text-sm text-slate-600">
                        Icons should be instantly recognizable. Use familiar shapes and metaphors that users already understand.
                      </div>
                    </div>
                    <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                      <div className="mb-1">✨ Simplicity</div>
                      <div className="text-sm text-slate-600">
                        Remove unnecessary details. Focus on the essential elements that convey the icon's meaning.
                      </div>
                    </div>
                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="mb-1">📏 Consistency</div>
                      <div className="text-sm text-slate-600">
                        Maintain consistent stroke width, style, and size across all icons in your set.
                      </div>
                    </div>
                    <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                      <div className="mb-1">👁️ Clarity</div>
                      <div className="text-sm text-slate-600">
                        Icons should be clear at any size. Test your icons at different scales to ensure visibility.
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="guidelines" className="space-y-4 mt-6">
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm flex-shrink-0 mt-0.5">1</div>
                      <div>
                        <div className="mb-1">Grid & Alignment</div>
                        <div className="text-sm text-slate-600">Use a consistent grid system to align elements within your icons.</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm flex-shrink-0 mt-0.5">2</div>
                      <div>
                        <div className="mb-1">Optical Balance</div>
                        <div className="text-sm text-slate-600">Balance visual weight, not just geometric center. Some shapes need adjustment.</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm flex-shrink-0 mt-0.5">3</div>
                      <div>
                        <div className="mb-1">Stroke Consistency</div>
                        <div className="text-sm text-slate-600">Keep stroke widths uniform. Typically 1.5-2.5px for outline icons.</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm flex-shrink-0 mt-0.5">4</div>
                      <div>
                        <div className="mb-1">Corner Radius</div>
                        <div className="text-sm text-slate-600">Use consistent corner radius values for a cohesive look.</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center text-sm flex-shrink-0 mt-0.5">5</div>
                      <div>
                        <div className="mb-1">Test at Scale</div>
                        <div className="text-sm text-slate-600">Always test icons at their intended display size (16px, 24px, 32px).</div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="examples" className="mt-6">
                  <div className="space-y-4">
                    <div>
                      <div className="mb-3">Example Usage Contexts:</div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-slate-50 rounded-lg">
                          <div className="text-sm mb-3">Mobile App</div>
                          <div className="flex items-center gap-3 p-3 bg-white rounded border">
                            <IconComponent
                              style={{ 
                                color: iconColor,
                                width: 24,
                                height: 24,
                                strokeWidth: strokeWidth,
                                fill: iconStyle === 'filled' ? iconColor : 'none'
                              }}
                            />
                            <div>
                              <div className="text-sm">72°F</div>
                              <div className="text-xs text-slate-500">San Francisco</div>
                            </div>
                          </div>
                        </div>
                        <div className="p-4 bg-slate-50 rounded-lg">
                          <div className="text-sm mb-3">Dashboard Widget</div>
                          <div className="p-3 bg-white rounded border">
                            <div className="flex items-center justify-between mb-2">
                              <div className="text-sm">Today</div>
                              <IconComponent
                                style={{ 
                                  color: iconColor,
                                  width: 32,
                                  height: 32,
                                  strokeWidth: strokeWidth,
                                  fill: iconStyle === 'filled' ? iconColor : 'none'
                                }}
                              />
                            </div>
                            <div className="text-sm text-slate-600">Perfect weather</div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="mb-1">💡 Pro Tip</div>
                      <div className="text-sm text-slate-600">
                        Weather icons benefit from using universally recognized symbols. The sun, clouds, and rain drops are understood globally without text labels.
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
